**IMPORTANT** look into why varscan called only two chromosomes in MMRF_1016.  Is this a bug?


From David Heiman 12/16/19,

    In regards to the VCF you sent, the AD FORMAT field is still invalid:
    The below definition
    ##FORMAT=<ID=AD,Number=R,Type=Integer,Description="Allelic depths for the ref and alt alleles in the order listed">
    means that the AD field should always have at least 2 values, separated by
    commas. However the very first call in the file only has a single value for the
    AD field in both the NORMAL and TUMOR columns, which will cause any VCF tool
    that includes built-in validation to crash on this VCF.

    An important piece of information that we need for downstream analysis and QC
    of all Somatic Mutations is alt and ref allele coverage. We usually use the AD
    Format field of a VCF for this. So long as it's represented in some way then we
    are good to go. This might require some post-processing of VCFs before merging
    in order to ensure this information is represented in the final file.

We should be able to modify varscan VCF file so that outputs allelic depths as comma-separated values in AD field.
Houxiang writes (slack, 12/19/19),
    Yes. I think it's not an issue. It is just a different format. When I check the
    official website of Varscan, it says: 

        VarScan reports variants on a biallelic basis. That is, for a given SNP call,
        the "reads1" column is the number of reference-supporting reads (RD), and the
        "reads2" column is the number of variant-supporting reads (AD).  Genotype
        format in the vcf file for each pool is assumed to contain either i) an AD
        field containing allele counts separated by a comma (as produced by popular
        software such as GATK or samtools/bcftools) or ii) both a RD (reference allele
        count) and a AD (alternate allele count) as obtained with the VarScan
        mpileup2snp program (when run with the –output-vcf option).

One question is how the documentation fields of VCFs get transfered during merge step.  To investigate,
look at VCF file from MMRF run, which has the new caller prioritization.

MMRF analysis_summary file:
    /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/MMRF_WXS_restart/dat/analysis_summary.dat

Looking at MMRF_1016 restart run results here:
    /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c

Arguments to GATK CombineVariants, from /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/test/call-merge_vcf/execution/stderr
GATK CombineVariants documentation: https://software.broadinstitute.org/gatk/documentation/tooldocs/3.8-0/org_broadinstitute_gatk_tools_walkers_variantutils_CombineVariants.php

    -R /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/1144374496/hs37d5_plusRibo_plusOncoViruses_plusERCC.20170530.fa 
    -T CombineVariants 
    -o results/merged/merged.vcf 
    --variant:varscan /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/-376967701/filtered.vcf 
    --variant:strelka /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/700461433/filtered.vcf 
    --variant:mutect /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/-566295909/filtered.vcf 
    --variant:varindel /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/-1209874506/filtered.vcf 
    --variant:sindel /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/1287059004/filtered.vcf 
    --variant:pindel /cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/call-merge_vcf/inputs/-487287701/filtered.vcf 
    -genotypeMergeOptions PRIORITIZE 
    -priority varscan,mutect,strelka,varindel,pindel,sindel 
    -U ALLOW_SEQ_DICT_INCOMPATIBILITY

However, the inputs to this merge rerun are located in the relevant restart YAML file:
/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/MMRF_WXS_restart/logs/stashed/39183d6d-0195-4249-bae1-a0510cf4ff5c/MMRF_1016.yaml

In particular,

pindel_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-pindel_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf
varscan_snv_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-varscan_snv_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf
varscan_indel_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-varscan_indel_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf
strelka_snv_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-strelka_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf
strelka_indel_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-strelka_indel_vaf_length_depth/execution/results/vaf_length_depth_filters/filtered.vcf
mutect_vcf: /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-mutect_vaf_length_depth/execution/results/vaf_length_depth_filters/filtered.vcf

We copy and rename the above to dat.  Also, 
copy /gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy-postcall.cwl/39183d6d-0195-4249-bae1-a0510cf4ff5c/test/call-merge_vcf/execution/results/merged/merged.vcf to dat

Note, though, that these varscan results cover only through chrom 2.  Did it crash?

Analysis

In general, both the INFO and FORMAT meta-information lines of the merged file
is a union of these lines from the input VCFs.  Merging does add the folowing
INFO fields: "set", "AN", "AF", "AC".  In cases where a given key value occurs
in more than one input VCF, the meta-information line from the highest priority
caller is used.  An exception to this is the AD field, where the value seems to
be partly from the mutect value:
```
    merged.header:##FORMAT=<ID=AD,Number=R,Type=Integer,Description="Allelic depths for the ref and alt alleles in the order listed">
    mutect_vcf.header:##FORMAT=<ID=AD,Number=.,Type=Integer,Description="Allelic depths for the ref and alt alleles in the order listed">
    pindel_vcf.header:##FORMAT=<ID=AD,Number=2,Type=Integer,Description="Allele depth, how many reads support this allele">
    varscan_indel_vcf.header:##FORMAT=<ID=AD,Number=1,Type=Integer,Description="Depth of variant-supporting bases (reads2)">
    varscan_snv_vcf.header:##FORMAT=<ID=AD,Number=1,Type=Integer,Description="Depth of variant-supporting bases (reads2)">
```

Note that the description is from mutect_vcf, but the Number field is R (From VCF 4.2 documentation, 
"If the field has one value for each possible allele (including the reference), then this value should be ‘R’.")

## diving into one variant

Look at this variant in more detail:
    1   114938679   .   G   A


F="mutect_vcf.vcf"
C=10 (TUMOR)
C=11 (NORMAL)

# This pretty prints INFO
grep 114938679 $F | cut -f 8 | tr ';' '\n'

# This pretty prints FORMAT and tumor or normal depending on value of $C
paste <(grep 114938679 $F | cut -f 9 | tr ':' '\n') <(grep 114938679 $F | cut -f $C | tr ':' '\n')



### mutect_vcf.vcf
1    114938679   .   G   A   .   PASS    SOMATIC;VT=SNP  GT:AD:BQ:DP:FA:SS   0/1:73,9:33.0:82:0.11:2 0:74,0:.:74:0.0:0

##INFO=<ID=DB,Number=0,Type=Flag,Description="dbSNP Membership">
##INFO=<ID=MQ0,Number=1,Type=Integer,Description="Total Mapping Quality Zero Reads">
##INFO=<ID=SOMATIC,Number=0,Type=Flag,Description="Somatic event">
##INFO=<ID=VT,Number=1,Type=String,Description="Variant type, can be SNP, INS or DEL">

INFO:
    SOMATIC
    VT=SNP

##FORMAT=<ID=AD,Number=.,Type=Integer,Description="Allelic depths for the ref and alt alleles in the order listed">
##FORMAT=<ID=BQ,Number=A,Type=Float,Description="Average base quality for reads supporting alleles">
##FORMAT=<ID=DP,Number=1,Type=Integer,Description="Approximate read depth (reads with MQ=255 or with bad mates are filtered)">
##FORMAT=<ID=FA,Number=A,Type=Float,Description="Allele fraction of the alternate allele with regard to reference">
##FORMAT=<ID=GQ,Number=1,Type=Integer,Description="Genotype Quality">
##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">
##FORMAT=<ID=PL,Number=G,Type=Integer,Description="Normalized, Phred-scaled likelihoods for genotypes as defined in the VCF specification">
##FORMAT=<ID=SS,Number=1,Type=Integer,Description="Variant status relative to non-adjacent Normal,0=wildtype,1=germline,2=somatic,3=LOH,4=post-transcriptional modification,5=unknown">

FORMAT / TUMOR:
GT  0/1
AD  73,9
BQ  33.0
DP  82
FA  0.11
SS  2

FORMAT / NORMAL
GT  0
AD  74,0
BQ  .
DP  74
FA  0.0
SS  0

### strelka_snv_vcf.vcf
1   114938679   .   G   A   .   PASS    QSS=81;TQSS=1;NT=ref;QSS_NT=81;TQSS_NT=1;SGT=GG->AG;SOMATIC;DP=166;MQ=60.0;MQ0=0;ReadPosRankSum=1.65;SNVSB=0.0;SomaticEVS=17.82 DP:FDP:SDP:SUBDP:AU:CU:GU:TU    79:0:0:0:0,0:0,0:79,79:0,0  87:0:0:0:9,9:0,0:78,78:0,0
##INFO=<ID=QSS,Number=1,Type=Integer,Description="Quality score for any somatic snv, ie. for the ALT allele to be present at a significantly different frequency in the tumor and normal">
##INFO=<ID=TQSS,Number=1,Type=Integer,Description="Data tier used to compute QSS">
##INFO=<ID=NT,Number=1,Type=String,Description="Genotype of the normal in all data tiers, as used to classify somatic variants. One of {ref,het,hom,conflict}.">
##INFO=<ID=QSS_NT,Number=1,Type=Integer,Description="Quality score reflecting the joint probability of a somatic variant and NT">
##INFO=<ID=TQSS_NT,Number=1,Type=Integer,Description="Data tier used to compute QSS_NT">
##INFO=<ID=SGT,Number=1,Type=String,Description="Most likely somatic genotype excluding normal noise states">
##INFO=<ID=SOMATIC,Number=0,Type=Flag,Description="Somatic mutation">
##INFO=<ID=DP,Number=1,Type=Integer,Description="Combined depth across samples">
##INFO=<ID=MQ,Number=1,Type=Float,Description="RMS Mapping Quality">
##INFO=<ID=MQ0,Number=1,Type=Integer,Description="Total Mapping Quality Zero Reads">
##INFO=<ID=ReadPosRankSum,Number=1,Type=Float,Description="Z-score from Wilcoxon rank sum test of Alt Vs. Ref read-position in the tumor">
##INFO=<ID=SNVSB,Number=1,Type=Float,Description="Somatic SNV site strand bias">
##INFO=<ID=PNOISE,Number=1,Type=Float,Description="Fraction of panel containing non-reference noise at this site">
##INFO=<ID=PNOISE2,Number=1,Type=Float,Description="Fraction of panel containing more than one non-reference noise obs at this site">
##INFO=<ID=SomaticEVS,Number=1,Type=Float,Description="Somatic Empirical Variant Score (EVS) expressing the phred-scaled probability of the call being a false positive observatio

INFO:
QSS=81
TQSS=1
NT=ref
QSS_NT=81
TQSS_NT=1
SGT=GG->AG
SOMATIC
DP=166
MQ=60.0
MQ0=0
ReadPosRankSum=1.65
SNVSB=0.0
SomaticEVS=17.82

##FORMAT=<ID=DP,Number=1,Type=Integer,Description="Read depth for tier1 (used+filtered)">
##FORMAT=<ID=FDP,Number=1,Type=Integer,Description="Number of basecalls filtered from original read depth for tier1">
##FORMAT=<ID=SDP,Number=1,Type=Integer,Description="Number of reads with deletions spanning this site at tier1">
##FORMAT=<ID=SUBDP,Number=1,Type=Integer,Description="Number of reads below tier1 mapping quality threshold aligned across this site">
##FORMAT=<ID=AU,Number=2,Type=Integer,Description="Number of 'A' alleles used in tiers 1,2">
##FORMAT=<ID=CU,Number=2,Type=Integer,Description="Number of 'C' alleles used in tiers 1,2">
##FORMAT=<ID=GU,Number=2,Type=Integer,Description="Number of 'G' alleles used in tiers 1,2">
##FORMAT=<ID=TU,Number=2,Type=Integer,Description="Number of 'T' alleles used in tiers 1,2">

FORMAT / TUMOR:
DP  79
FDP 0
SDP 0
SUBDP   0
AU  0,0
CU  0,0
GU  79,79
TU  0,0

FORMAT / NORMAL
DP  87
FDP 0
SDP 0
SUBDP   0
AU  9,9
CU  0,0
GU  78,78
TU  0,0

### varscan_snv_vcf.vcf
1   114938679   .   G   A   .   PASS    DP=156;SOMATIC;SS=2;SSC=26;GPV=1.0;SPV=0.0024586    GT:GQ:DP:RD:AD:FREQ:DP4 0/0:.:74:74:0:0%:25,49,0,0  0/1:.:82:73:9:10.98%:17,56,1,8

##INFO=<ID=DP,Number=1,Type=Integer,Description="Total depth of quality bases">
##INFO=<ID=SOMATIC,Number=0,Type=Flag,Description="Indicates if record is a somatic mutation">
##INFO=<ID=SS,Number=1,Type=String,Description="Somatic status of variant (0=Reference,1=Germline,2=Somatic,3=LOH, or 5=Unknown)">
##INFO=<ID=SSC,Number=1,Type=String,Description="Somatic score in Phred scale (0-255) derived from somatic p-value">
##INFO=<ID=GPV,Number=1,Type=Float,Description="Fisher's Exact Test P-value of tumor+normal versus no variant for Germline calls">
##INFO=<ID=SPV,Number=1,Type=Float,Description="Fisher's Exact Test P-value of tumor versus normal for Somatic/LOH calls">

INFO
DP=156
SOMATIC
SS=2
SSC=26
GPV=1.0
SPV=0.0024586

##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">
##FORMAT=<ID=GQ,Number=1,Type=Integer,Description="Genotype Quality">
##FORMAT=<ID=DP,Number=1,Type=Integer,Description="Read Depth">
##FORMAT=<ID=RD,Number=1,Type=Integer,Description="Depth of reference-supporting bases (reads1)">
##FORMAT=<ID=AD,Number=1,Type=Integer,Description="Depth of variant-supporting bases (reads2)">
##FORMAT=<ID=FREQ,Number=1,Type=String,Description="Variant allele frequency">
##FORMAT=<ID=DP4,Number=1,Type=String,Description="Strand read counts: ref/fwd, ref/rev, var/fwd, var/rev">
TUMOR
GT  0/0
GQ  .
DP  74
RD  74
AD  0
FREQ    0%
DP4 25,49,0,0

NORMAL
GT  0/1
GQ  .
DP  82
RD  73
AD  9
FREQ    10.98%
DP4 17,56,1,8

### merged.vcf
```
1    114938679   .   G   A   .   PASS    AC=1;AF=0.250;AN=4;DP=322;SOMATIC;set=varscan-mutect-strelka    GT:AD:DP:DP4:FREQ:RD    0/0:0:74:25,49,0,0:0%:74    0/1:9:82:17,56,1,8:10.98%:73
```
##INFO=<ID=AC,Number=A,Type=Integer,Description="Allele count in genotypes, for each ALT allele, in the same order as listed">
##INFO=<ID=AF,Number=A,Type=Float,Description="Allele Frequency, for each ALT allele, in the same order as listed">
##INFO=<ID=AN,Number=1,Type=Integer,Description="Total number of alleles in called genotypes">

AC=1
AF=0.250
AN=4
DP=322
SOMATIC
set=varscan-mutect-strelka

**NOTE** DP is reset by merge step, not clear where value of 322 from

FORMAT / TUMOR

GT  0/0
AD  0
DP  74
DP4 25,49,0,0
FREQ    0%
RD  74

FORMAT / NORMAL

GT  0/1
AD  9
DP  82
DP4 17,56,1,8
FREQ    10.98%
RD  73

Required changes to Varscan VCF

Documentation: http://varscan.sourceforge.net/somatic-calling.html
    AD - Reads supporting variant in tumor (or normal)
    RD - Reads supporting reference in tumor (or normal)

We want to change the value of AD to match that in mutect_vcf.  Specifically, we want,
    AD_new = RD_old,AD_old
    RD_new - delete it

Update meta-information 
    ##FORMAT=<ID=AD,Number=R,Type=Integer,Description="Allelic depths for the ref and alt alleles in the order listed">

Delete ID=RD FORMAT field


