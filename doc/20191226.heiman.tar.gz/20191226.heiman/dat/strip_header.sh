mkdir -p headers

for F in merged.vcf mutect_vcf.vcf pindel_vcf.vcf strelka_indel_vcf.vcf strelka_snv_vcf.vcf varscan_indel_vcf.vcf varscan_snv_vcf.vcf; do

#B=$(basename $F)

B="${F%.*}"
OUT="headers/${B}.header"
grep "^##" $F | grep -v contig= > $OUT

echo Reading $F
echo Writing $OUT

done

