
for F in *.header; do

echo Reading $F

grep "^##INFO" $F | cut -f 2- -d "=" | cut -f 1 -d , | cut -f 2 -d '=' | sort > $F.info
grep "^##FILTER" $F | cut -f 2- -d "=" | cut -f 1 -d , | cut -f 2 -d '=' | sort > $F.filter
grep "^##FORMAT" $F | cut -f 2- -d "=" | cut -f 1 -d , | cut -f 2 -d '=' | sort > $F.format

done

