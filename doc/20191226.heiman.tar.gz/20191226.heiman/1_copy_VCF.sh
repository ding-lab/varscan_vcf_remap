

OUT="dat/pindel_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-pindel_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT

OUT="dat/varscan_snv_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-varscan_snv_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT

OUT="dat/varscan_indel_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-varscan_indel_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT

OUT="dat/strelka_snv_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-strelka_vaf_length_depth_filters/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT

OUT="dat/strelka_indel_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-strelka_indel_vaf_length_depth/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT

OUT="dat/mutect_vcf.vcf"
IN="/gscmnt/gc2737/ding/fernanda/Somatic_MMY/MMRF/Results/cromwell-workdir/cromwell-executions/tindaisy.cwl/2c210004-7e16-49cf-8c0c-7dcee82ace2f/call-mutect_vaf_length_depth/execution/results/vaf_length_depth_filters/filtered.vcf"
cp $IN $OUT
